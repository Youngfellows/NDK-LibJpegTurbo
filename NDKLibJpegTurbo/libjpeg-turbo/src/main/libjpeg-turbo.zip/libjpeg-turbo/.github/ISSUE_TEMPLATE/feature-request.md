---
name: Feature Request
about: Suggest new libjpeg-turbo functionality
title: ''
labels: enhancement
assignees: dcommander

---
